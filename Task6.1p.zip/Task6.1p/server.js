const express = require("express")
const bodyParser = require("body-parser")
const mongoose = require("mongoose")
const Expert = require("./models/Expert.js")
const app = express();


app.use(bodyParser.urlencoded({ extended: true }));
mongoose.connect("mongodb+srv://admin123:admin123@cluster0.4wos5.mongodb.net/myFirstDatabase?retryWrites=true&w=majority", { useNewUrlParser: true, })


app.route('/experts')
    .get((req, res) => {
        Expert.find((err, expertsList) => {
            if (err) { res.send(err) } else { res.send(expertsList) }
        })
    })
    .post((req, res) => {
        const expert = new Expert({
            expert_name: req.body.name,
            expert_password: req.body.password,
            expert_address: req.body.address,
            expert_mobile: req.body.mobile
        })
        expert.save((err) => {
            if (err) { res.send(err) } else res.send('Successfully added a new expert!')
        })
    })
    .delete((req, res) => {
        Expert.deleteMany((err) => {
            if (err) { res.send(err) } else { res.send('Successfully deleted all experts!') }
        })
    })

app.route('/experts/:id')
    .get((req, res) => {
        Expert.findOne({ expert_name: req.params.id }, { expert_password: req.params.id }, { expert_address: req.params.id }, { expert_mobile: req.params.id },
            (err, foundExpert) => {
                if (foundExpert)(res.send(foundExpert))
                else res.send("No Matched Expert Found!")
            })
    })
    .put((req, res) => {
        Expert.update({ expert_name: req.params.id }, { expert_name: req.body.name }, { overwrite: true },
            (err) => {
                if (err) { res.send(err) } else { res.send('Successfully updated!') }
            }
        )
    })

.patch((req, res) => {
    Expert.update({ expert_name: req.params.id }, { $set: req.body },
        (err) => {
            if (!err) { res.send('Successfully updated! ') } else res.send(err)
        }
    )
})

app.listen(process.env.PORT || 8000, () => {
    console.log('Server started on port 8000');
})